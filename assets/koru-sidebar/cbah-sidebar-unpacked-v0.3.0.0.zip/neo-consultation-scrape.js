/**
 * IDEXX Neo Consultation Scraper Script
 * Runs in the MAIN world context of the active Neo consultation page.
 * Async IIFE: Chrome MV3 awaits the returned promise from executeScript.
 */
(async () => {
    // 0. Consultation, Patient, & Client Identifiers
    const urlMatch = window.location.pathname.match(/\/consultations\/view\/(\d+)/);
    const consultEditEl = document.querySelector('[data-qa="consultation-edit"]');
    const consultEditMatch = consultEditEl?.textContent?.match(/Consultation\s+(\d+)/i);
    const consultationId = urlMatch?.[1] || consultEditMatch?.[1] || null;

    const patientIdEl = document.querySelector('[data-qa="patient-signalment-id"]');
    const patientLink = document.querySelector('[data-qa="patient-signalment-patient-name"] a') ||
                        document.querySelector('a[href*="/patients/view/"]');
    const patientHrefMatch = patientLink?.getAttribute('href')?.match(/\/patients\/view\/(\d+)/);
    const patientId = patientIdEl?.textContent?.trim() || patientHrefMatch?.[1] || null;
    const patientName = patientLink?.textContent?.trim() || null;

    const clientLink = document.querySelector('a[data-qa="client-link"]') ||
                       document.querySelector('a[href*="/clients/view/"]');
    const clientHrefMatch = clientLink?.getAttribute('href')?.match(/\/clients\/view\/(\d+)/);
    const clientId = clientHrefMatch?.[1] || null;
    const clientName = clientLink?.textContent?.trim() || null;

    // Optional Embedded Page Metadata Fallback
    let scriptData = null;
    try {
        if (typeof window.angularOptions !== 'undefined' && window.angularOptions?.activePatient) {
            scriptData = window.angularOptions.activePatient;
        }
    } catch (e) {}

    const resolvedConsultationId = consultationId || (scriptData?.consultation_id ? String(scriptData.consultation_id) : null);
    const resolvedClientId = clientId || (scriptData?.client_id ? String(scriptData.client_id) : null);
    const resolvedClientName = clientName || (scriptData ? `${scriptData.first_name || ''} ${scriptData.last_name || ''}`.trim() : null);
    const resolvedPatientId = patientId || (scriptData?.patient_id ? String(scriptData.patient_id) : null);
    const resolvedPatientName = patientName || scriptData?.patient_name || null;

    // --- Consultation Date ---
    const consultDateInput =
        document.querySelector('app-single-date-picker[data-qa="consultation-consulted-at"] input') ||
        document.querySelector('input[data-qa^="datepicker-consultation-consulted-at"]') ||
        document.querySelector('#consultationHeader .consultation-header-date input');
    const consultationDate = consultDateInput?.value?.trim() || null;

    // 1. Provider
    let provider = null;
    const providerSelect = document.querySelector('select#provider-select');
    if (providerSelect && providerSelect.selectedOptions && providerSelect.selectedOptions.length > 0) {
        provider = providerSelect.selectedOptions[0].innerText?.trim() || providerSelect.selectedOptions[0].textContent?.trim() || null;
    } else if (providerSelect && providerSelect.options && providerSelect.selectedIndex >= 0) {
        provider = providerSelect.options[providerSelect.selectedIndex].text?.trim() || null;
    }

    // 2. Reason (Consultation Header / Signalment Reason + Description)
    let reason = null;
    const reasonLabel = Array.from(document.querySelectorAll('#consultationBody label, label.spot-form__label'))
        .find(el => el.textContent && el.textContent.includes('Reason:'));

    const reasonType = reasonLabel?.querySelector('.spot-typography__font-weight--bold')?.textContent?.trim()
        || reasonLabel?.textContent?.replace(/^Reason:\s*/i, '')?.trim()
        || '';

    const descInput = document.querySelector('[data-qa="description-textbox"] input, spot-textbox[formcontrolname="description"] input');
    const reasonDescription = descInput?.value?.trim() || '';

    const combinedReason = [reasonType, reasonDescription].filter(Boolean).join(' - ');
    if (combinedReason) {
        reason = combinedReason;
    }

    // 3. Vitals (Temperature, Pulse, Respiration, Weight & Units)
    const tempVal = document.querySelector('input#temperature')?.value?.trim();
    const pulseVal = document.querySelector('input#pulse')?.value?.trim();
    const respVal = document.querySelector('input#respiration')?.value?.trim();
    const weightVal = document.querySelector('input#weight, [data-qa="vital-sign-weight"] input')?.value?.trim();

    const unitSelect = document.querySelector('select#weightUnit, [data-qa="vital-sign-weight-unit"] select');
    let weightUnit = null;
    if (unitSelect) {
        if (unitSelect.selectedOptions && unitSelect.selectedOptions.length > 0) {
            weightUnit = unitSelect.selectedOptions[0].textContent.trim();
        } else if (unitSelect.value) {
            weightUnit = unitSelect.value.replace(/^\d+:\s*/, '').trim();
        }
    }

    let resolvedWeight = weightVal || null;
    let resolvedWeightUnit = weightUnit || null;

    if (!resolvedWeight) {
        const ths = Array.from(document.querySelectorAll('table th, .patient-quicklist th'));
        const weightTh = ths.find(th => th.textContent.trim().toLowerCase() === 'weight');
        if (weightTh) {
            const colIdx = Array.from(weightTh.parentElement.children).indexOf(weightTh);
            const table = weightTh.closest('table');
            const row = table?.querySelector('tbody tr') || weightTh.parentElement.nextElementSibling;
            const cellText = row?.children[colIdx]?.textContent?.trim() || '';
            const match = cellText.match(/^([0-9.]+)\s*([a-zA-Z]+)/);
            if (match) {
                resolvedWeight = match[1];
                if (!resolvedWeightUnit) resolvedWeightUnit = match[2];
            }
        }
    }

    const vitals = {
        temperature: tempVal || null,
        pulse: pulseVal || null,
        respiration: respVal || null,
        weight: resolvedWeight,
        weightUnit: resolvedWeightUnit
    };

    // 4. Notes (Rich-text field via CKEditor 4)
    let notes = null;
    if (typeof window.CKEDITOR !== 'undefined' && window.CKEDITOR.instances) {
        if (window.CKEDITOR.instances['editor1'] && typeof window.CKEDITOR.instances['editor1'].getData === 'function') {
            notes = window.CKEDITOR.instances['editor1'].getData();
        } else {
            const firstInstance = Object.values(window.CKEDITOR.instances)[0];
            if (firstInstance && typeof firstInstance.getData === 'function') {
                notes = firstInstance.getData();
            }
        }
    }

    // Fallback: Check iframe if CKEditor global instance data wasn't found
    if (!notes) {
        const iframe = document.querySelector('iframe.cke_wysiwyg_frame');
        if (iframe && iframe.contentDocument && iframe.contentDocument.body) {
            notes = iframe.contentDocument.body.innerHTML;
        }
    }

    if (notes) {
        notes = notes.trim();
        if (notes === '') {
            notes = null;
        }
    }

    // 5. Invoice Lines (Handles both active and closed/view-only tables)
    const rows = Array.from(document.querySelectorAll(
        'table.consultation-lines-table tbody tr[app-consultation-line]:not([hidden]), table.consultation-lines-table tbody tr[data-qa^="consultation-line-id-"]:not([data-qa="consultation-line-id-null"]):not([hidden])'
    ));

    const invoiceLines = rows.map((row, idx) => {
        // Product / Service description
        const productEl = row.querySelector('[data-qa="product-service"] textarea, [data-qa="product-service"] input, .column-product-service textarea, .column-product-service input');
        const description = productEl?.value?.trim() || productEl?.innerText?.trim() || '';

        // Label / Instructions
        const labelEl = row.querySelector('[data-qa="product-line-label"] textarea, .column-label textarea');
        const label = labelEl?.value?.trim() || labelEl?.innerText?.trim() || null;

        // Date
        const dateInput = row.querySelector('[data-qa="product-line-date"] input, .column-date input');
        const date = dateInput?.value?.trim() || null;

        // Provider
        const lineProviderSelect = row.querySelector('[data-qa="product-line-provider"] select, .column-provider select');
        let lineProvider = null;
        if (lineProviderSelect && lineProviderSelect.selectedIndex >= 0) {
            lineProvider = lineProviderSelect.options[lineProviderSelect.selectedIndex]?.innerText?.trim() || lineProviderSelect.value?.trim() || null;
        }

        // Quantity
        const qtyInput = row.querySelector('[data-qa="product-line-quantity"] input, .column-quantity input');
        const qty = qtyInput?.value?.trim() || '';

        // Price
        const priceInput = row.querySelector('[data-qa="price-excluding-tax"] input, .column-price input');
        const price = priceInput?.value?.trim() || row.querySelector('.price')?.innerText?.trim() || '';

        // Optional discount & Rx ID badges
        const discount = row.querySelector('[data-qa="discount"]')?.innerText?.trim() || null;
        const rxEl = row.querySelector('.column-product-service .fa-medkit')?.parentElement;
        const rxId = rxEl?.innerText?.trim() || null;

        return {
            qty,
            description,
            label,
            date,
            provider: lineProvider,
            price,
            discount,
            rxId
        };
    });

    // 6. Consultation Invoice Totals
    const totals = {
        subtotal: document.querySelector('[data-qa="consultation-totals-subtotal"]')?.innerText?.trim() || null,
        discountTotal: document.querySelector('[data-qa="consultation-totals-discount"]')?.innerText?.trim() || null,
        taxTotal: document.querySelector('[data-qa="consultation-totals-tax"]')?.innerText?.trim() || null,
        total: document.querySelector('[data-qa="consultation-totals-total"]')?.innerText?.trim() || null
    };

    // 7. Client email — server-rendered on /clients/view/{id}
    const clientEmail = await fetchClientEmail(resolvedClientId);

    return {
        scrapedAt: new Date().toISOString(),
        consultationId: resolvedConsultationId,
        consultationDate: consultationDate,
        clientId: resolvedClientId,
        clientName: resolvedClientName,
        clientEmail: clientEmail,
        patientId: resolvedPatientId,
        patientName: resolvedPatientName,
        provider: provider || null,
        reason: reason || null,
        vitals: vitals,
        notes: notes || null,
        invoiceLines: invoiceLines,
        totals: totals
    };

    async function fetchClientEmail(clientId) {
        if (!clientId) return null;
        try {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 4000);
            const res = await fetch(`/clients/view/${clientId}`, { signal: controller.signal });
            clearTimeout(timer);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const html = await res.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            return doc.querySelector('input#client_email')?.value?.trim() || null;
        } catch (err) {
            console.error(`[CBAH Sidebar] Failed to fetch email for client ${clientId}:`, err);
            return null;
        }
    }
})();
